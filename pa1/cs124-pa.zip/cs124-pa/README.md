Compile program using:
g++ -std=c++17 -o randmst randmst.cc
